
# Biyobellek

Bu proje, ezberlemek istenen metinleri hafıza teknikleriyle kodlayan bir uygulamadır. React ve Tailwind ile geliştirilmiştir.
